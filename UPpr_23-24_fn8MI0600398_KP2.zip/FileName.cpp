/**
*
* Solution to course project # 2
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2023/2024
*
* @author Zhan Georgiev Georgiev
* @idnumber 8MI0600398
* @compiler VC
*
* <main file>
*
*/


#include<iostream>
#include<fstream>
#include <cstdlib>

const int SIZE = 100;
const int STRING_SIZE = 128;
const int MAX_Y = 24;
const int MAX_X = 80;

int strlen(char* line)
{
	int lenght = 0;
	
	while (*line)
	{
		lenght++;
		line++;
	}

	return lenght;
}

int validation(char* a)
{
	int number = 0;
	while (strlen(a) != 1 || *a < '0' || *a > '9')
		//we expect to get as input a number between 0 and 9
		//it means that if the input is made of more than 1 digit
		//or it is a symbol different form digits (0-9)
	{
		std::cout << "Please enter valid value" << std::endl;;
		std::cin >> a;
	};
	return *a - '0';
}

void chekBorders(char matrix[SIZE][SIZE], bool chek[SIZE][SIZE], int& n, int& m)
{
	bool expandUp = false;
	bool expandRight = false;
	bool expandDown = false;
	bool expandLeft = false;

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
		{
			if (chek[0][j] == 1)
			{
				expandUp = true;
			}
			if (chek[n - 1][j] == 1) 
			{
				expandDown = true;
			}
			if (chek[i][m - 1] == 1) 
			{
				expandRight = true;
			}
			if (chek[i][0] == 1) 
			{
				expandLeft = true;
			}
			//cheks if the part of the matrix that we do not see
			//is going to turn a dead cell into live one
		}
	}

	if (expandUp)
	{
		n++;
		
		for (int i = n; i >= 0; i--)
		{
			for (int j = m; j >= 0; j--)
			{
				if (chek[i][j] == 1)
				{
					chek[i][j] = 0;
					chek[i + 1][j] = 1;
					//move living cells 
				}
			}
		}
	}

	if (expandRight)
	{
		m++;
		//we expand the matrix right
	}

	if (expandDown)
	{
		n++;
		//we expand the matrix down
	}

	if (expandLeft)
	{
		m++;
		for (int i = n; i >= 0; i--)
		{
			for (int j = m; j >= 0; j--)
			{
				if (chek[i][j] == 1)
				{
					chek[i][j] = 0;
					chek[i][j + 1] = 1;
					//move living cells to the right
				}
			}
		}
	}
}

int countMatrix(char matrix[SIZE][SIZE], int i, int j, int n, int m)
{
	int count = 0;

	if (matrix[i - 1][j - 1] == '&') 
	{
		count++;
	}
	if (matrix[i - 1][j] == '&')
	{
		count++;
	}
	if (matrix[i - 1][j + 1] == '&') 
	{
		count++;
	}
	if (matrix[i][j + 1] == '&') 
	{
		count++;
	}
	if (matrix[i][j - 1] == '&') 
	{
		count++;
	}
	if (matrix[i + 1][j - 1] == '&') 
	{
		count++;
	}
	if (matrix[i + 1][j] == '&') 
	{
		count++;
	}
	if (matrix[i + 1][j + 1] == '&') 
	{
		count++;
	}
	//this function checks the neighboring cells 
	//and counts how many live cells there are

	return count;
}

int lenght(int n)
{
	int indent = 0;
	while (n)
	//when the number becomes 0 while the loop stops
	{
		n = n / 10;
		indent++;
	}
	return indent;
	//this function counts from how many digits there are in a number
}

void top(const int indent, const int m, const int n)
{
	for(int i = 0; i < indent + m - lenght(m); i++)
	//indent is the number of digits used to write 
	//the number of rows
	//lenght(m) is the numbers used to write the number of columns
	{
		if (i == lenght(n) && m != 1) 
		{
			std::cout << "1";
	//knowing that our matrix is at least 1x1 we print 1 
	//if m == 1 we print 1 only ones
		}
		else std::cout << " ";
	}
		std::cout << m;
}

void leftBorder(const int indent)
{
	for (int i = 0; i < indent ; i++)
	{	
		std::cout << " ";
	}
}

int drawMatrix(const char matrix[SIZE][SIZE], int n, int m)
{
	n = n - 2;
	m = m - 2;
	
	int indent = lenght(n);

	top(indent, m, n);
	std::cout << std::endl;

	for (int i = 1; i <= n; i++)
	{
		if (n != 1)
		{
			if (i == 1)
			{
				leftBorder(indent - 1);
				std::cout << i;
			}	
		}

		if (i == n)
		{
			std::cout << n;
		}

		if (i > 1 && i < n)
		{
			leftBorder(indent);
		}

		for (int j = 1; j <= m ; j++)
		{
			std::cout << matrix[i][j];
		}
		std::cout << std::endl;
	}
	return 0;
}

int chekMatrix(char matrix[SIZE][SIZE], int& n, int& m)
{
	bool chek[SIZE][SIZE] = {};
	//this is a matrix used to mark the 
	//status of cells 
	//if the element of this matrix is 1
	//it means that the cell has to live the next turn
	for (int i = 0; i <= n; i++)
	{
		for (int j = 0; j <= m; j++) {
			if (matrix[i][j] == '&' && countMatrix(matrix, i, j, n, m) < 2)
			{
				chek[i][j] = 0;
			}
			if (matrix[i][j] == '&' && countMatrix(matrix, i, j, n, m) == 2 ||
				matrix[i][j] == '&' && countMatrix(matrix, i, j, n, m) == 3)
			{
				chek[i][j] = 1;
			}
			if (matrix[i][j] == '&' && countMatrix(matrix, i, j, n, m) > 3) 
			{
				chek[i][j] = 0;
			}
			if (matrix[i][j] == '-' && countMatrix(matrix, i, j, n, m) == 3)
			{
				chek[i][j] = 1;
			}
		}
	}

	chekBorders(matrix, chek, n, m);

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++) 
		{
			if (chek[i][j] == 1) 
			{
				matrix[i][j] = '&';
			}
			else matrix[i][j] = '-';
		}
	}

	return 0;
}
void resize(char matrix[SIZE][SIZE], int& n, int& m, int y, int x)
{
	if (y == 0 && x == 0)
	{
		
		std::cin >> x;
		while (x < 0  || x > MAX_X)
		{
			std::cout << "Please enter x between 0 and 80" << std::endl;
			std::cin >> x;
		}
		std::cin >> y;
		while (y < 0 || y > MAX_Y)
		{
			std::cout << "Please enter y between 0 and 24" << std::endl;
			std::cin >> y;
		}
	}

	n = y + 2;
	m = x + 2;

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
		{
			if (i >= y - 1 || j >= x - 1) 
			{
				matrix[i][j] = '-';
			} 

			if (matrix[i][j] != '&')
			{
				matrix[i][j] = '-';
			}
		}
	}
}

void toggleCell(char matrix[SIZE][SIZE], int& n, int& m)
{
	int x = 0;
	int y = 0;

	std::cin >> x;

	while (x < 1 || x > m - 2)
	{
		std::cout << "Please enter x between 1 and " << m - 2 << std::endl;
		std::cin >> x;
	}
	std::cin >> y;
	while (y < 1 || y > n - 2)
	{
		std::cout << "Please enter y between 1 and " << n - 2 << std::endl;
		std::cin >> y;
	}


	if (matrix[y][x] == '-')
	{
		matrix[y][x] = '&';
	}
	else matrix[y][x] = '-';
	//this turns live cells into dead cells 
	//and dead cells in live cells
}

void clear(char matrix[SIZE][SIZE], const int n, const int m)
{
	for (int i = 0; i < SIZE; i++)
	{
		for (int j = 0; j < SIZE; j++)
		{
			matrix[i][j] = '-';
		}
	}
}
void findCorners(char matrix[SIZE][SIZE], int& x1, int& y1, int& x2, int& y2, const int n, const int m)
{
	x1 = m;
	y1 = n;
	x2 = 0;
	y2 = 0;

	for (int i = 0; i < SIZE; i++)
	{
		for (int j = 0; j < SIZE; j++)
		{
			if (matrix[i][j] == '&')
			{
				if (y1 > i)y1 = i;
				if (y2 < i)y2 = i;
				if (x1 > j)x1 = j;
				if (x2 < j)x2 = j;
		//this finds the cords of the part that we 
		//want to save to a file
			}
		}
	}
}

void saveMatrix(char matrix[SIZE][SIZE], const int n, const int m)
{
	int x1 = 0;
	int y1 = 0;
	int x2 = 0;
	int y2 = 0;

	findCorners(matrix, x1, y1, x2, y2, n, m);

	char fileName[STRING_SIZE] = "";
	std::cout << "Enter file name: ";
	std::cin >> fileName;

	std::ofstream myfile;
	myfile.open(fileName);

	for (int i = y1; i <= y2; i++)
	{
		for (int j = x1; j <= x2; j++)
		{
			myfile << matrix[i][j];
		}
		myfile << std::endl;
	}

	myfile.close();
}

void loadMatrix(char matrix[SIZE][SIZE], int& n, int& m)
{
	clear(matrix, n, m);

	char fileName[STRING_SIZE] = {};
	std::cout << "Enter file name: ";
	std::cin >> fileName;

	std::ifstream myfile;
	myfile.open(fileName);

	char line[STRING_SIZE] = {};
	myfile >> line;
	//write the first row into char array

	m = strlen(line) + 3;

	int j = 1;
	int k = 0;

	while (!myfile.eof())
		//while file is not empty
	{
		for (int i = 0; i <= m; i++)
		{
			if (i == 0 || i == m - 1) 
			{
				matrix[j][i] = '-';
				//this is the part of matrix we do not see
			}
			else matrix[j][i] = line[k++];
		}
		k = 0;
		myfile >> line;
		j++;
	}

	n = j + 1;

	myfile.close();

}

void random(char matrix[SIZE][SIZE], const int n, const int m)
{
	int percent = 0;

	std::cin >> percent;
	while(percent < 0) 
	{
		std::cout << "The number has to be positive " << std::endl;
		std::cin >> percent;
	}


	if (percent == 0) 
	{
		clear(matrix, n, m);
	} 
	
	for (int i = 1; i < n-1; i++)
	{
		for (int j = 1; j < m-1; j++)
		{
			if (std::rand() % percent == 0 ) 
			{
				
				matrix[i][j] = '&';
			}
			else matrix[i][j] = '-';
		}
	}
}

int main()
{
	char matrix[SIZE][SIZE] = {};
	int n = 8;
	int m = 16;
	bool startMenue = true;

	char a[STRING_SIZE] = "";
	int number = 0;
	
	resize(matrix, n, m, n, m);

	while (true)
	{
		if (startMenue)
		{

			std::cout << "New Game: 1" << std::endl;
			std::cout << "Load: 2" << std::endl;
			std::cout << "Exit: 3" << std::endl;
			

			std::cin >> a;
			number = validation(a);
			
			std::cout << std::endl;

			switch (number)
			{
			case 1:	
			{
				startMenue = false;
				break;
			}
			case 2:
			{
			startMenue = false;
				loadMatrix(matrix, n, m);
				break;
			}
			case 3:
			{
				return 0;
				break;
			}
			default:
			{
				std::cout << "Please enter valid value" << std::endl;
				break;
			}
			}
		}	

		if (!startMenue)
		{
			drawMatrix(matrix, n, m);
			std::cout << std::endl;
			std::cout << "Step forward: 1" << std::endl;
			std::cout << "Resize: 2" << std::endl;
			std::cout << "Toggle cell: 3" << std::endl;
			std::cout << "Clear: 4" << std::endl;
			std::cout << "Randomize: 5" << std::endl;
			std::cout << "Save to file: 6" << std::endl;
			std::cout << "End: 7" << std::endl;

			std::cin >> a;
			number = validation(a);
			std::cout << std::endl;

			switch (number)
			{
			case 1:chekMatrix(matrix, n, m);
				break;
			case 2:resize(matrix, n, m, 0, 0);
				break;
			case 3:toggleCell(matrix, n, m);
				break;
			case 4:clear(matrix, n, m);
				break;
			case 5:random(matrix, n, m);
				break;
			case 6:saveMatrix(matrix, n, m);
				break;
			case 7:startMenue = true;
				break;
			default:
				std::cout << "Please enter valid value" << std::endl;
				break;
			}
			if(n > MAX_Y || m > MAX_X)
			{
				std::cout<<"massive is too big"<<std::endl;
				clear(matrix,n,m);
			}
		}
	}
	return 0;
}
